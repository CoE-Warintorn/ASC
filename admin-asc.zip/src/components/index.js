import Header from './Header/Header';
import Table from './Table/Table';

export { Header, Table };
